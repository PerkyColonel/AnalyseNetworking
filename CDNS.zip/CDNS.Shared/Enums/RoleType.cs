namespace CDNS.Shared;

public enum RoleType
{
    Client,
    Server
}