namespace CDNS.Shared;

public enum DirectionType
{
    In,
    Out
}