# CDNS

A project for networking.

#Remarks

- Er staat in de template bij MessageType, een type genaamd DNSrecord. Maar deze word niet gebruikt.
- In de omschrijving staat dat de server een "end" message moet sturen als alle requesten zijn geweest. Maar hoe zou de server dit moeten weten zonder dat de client aangeeft dat er geen requests meer zijn.
- De voorbeelden en de omschrijving komt niet overeen met elkaar. In de omschrijving staat dat een DNSLookup message zowel een type als een value nodig heeft. Maar in de voorbeelden staat onder een goed voorbeeld dat er alleen value is. En bij foute onderdelen staat beide een value en type. Dit is erg verwarrend wat van ons verwacht word.
